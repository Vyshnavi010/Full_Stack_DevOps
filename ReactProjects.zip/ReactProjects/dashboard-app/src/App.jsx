import "./App.css";

import Welcome from "./components/welcome";
import CourseDetails from "./components/coursedetails";
import Message from "./components/message";

function App() {
  return (
    <div className="dashboard">
      <h1>Welcome to Startup Dashboard</h1>

      <Welcome />
      <CourseDetails />
      <Message />
    </div>
  );
}

export default App;
