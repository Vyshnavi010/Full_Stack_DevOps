function Welcome() {
  return (
    <div>
      <p>Hello User 👋</p>
    </div>
  );
}

export default Welcome;
